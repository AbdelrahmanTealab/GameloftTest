const graphql = require("graphql");
const {
    GraphQLObjectType,
    GraphQLInt, 
    GraphQLString,
    GraphQLList, 
    GraphQLBoolean} = graphql;

const Curator = new GraphQLObjectType({
    name:'curator',
    fields:()=>({
        href:{type: GraphQLString},
        data:{type: GraphQLList(Data)},
    })
})

const PlayParams = new GraphQLObjectType({
    name:'playParams',
    fields:()=>({
        id:{type: GraphQLString},
        kind:{type: GraphQLString},
    })
})

const Artwork = new GraphQLObjectType({
    name:'artwork',
    fields:()=>({
        width:{type: GraphQLInt},
        height:{type: GraphQLInt},
        url:{type: GraphQLString},
        bgColor:{type: GraphQLString},
        textColor1:{type: GraphQLString},
        textColor2:{type: GraphQLString},
        textColor3:{type: GraphQLString},
        textColor4:{type: GraphQLString},
    })
})

const Previews = new GraphQLObjectType({
    name:'previews',
    fields:()=>({
        url:{type: GraphQLString},
    })
})

const Attributes = new GraphQLObjectType({
    name:'mixAttributes',
    fields:()=>({
        artistName: {type: GraphQLString},
        url: {type: GraphQLString},
        discNumber: {type: GraphQLInt},
        durationInMillis: {type: GraphQLInt},
        releaseDate: {type: GraphQLString},
        name: {type: GraphQLString},
        isrc: {type: GraphQLString},
        hasLyrics: {type: GraphQLBoolean},
        albumName: {type: GraphQLString},
        trackNumber: {type: GraphQLInt},
        curatorName: {type: GraphQLString},
        composerName: {type: GraphQLString},
        playParams: {type: PlayParams},
        genreNames: {type: GraphQLList(GraphQLString)},
        artwork: {type: Artwork},
        previews: {type: GraphQLList(Previews)}
    })
})

const Data = new GraphQLObjectType({
    name:'data',
    fields:()=>({
        id:{type: GraphQLString},
        type:{type: GraphQLString},
        href:{type: GraphQLString},
        attributes:{type: Attributes},
    })
})

const Tracks = new GraphQLObjectType({
    name:'tracks',
    fields:()=>({
        href:{type: GraphQLString},
        next:{type: GraphQLString},
        data:{type: GraphQLList(Data)},
    })
})

const Relationships = new GraphQLObjectType({
    name:'relationships',
    fields:()=>({
        curator:{type: Curator},
        tracks:{type: Tracks},
    })
})

const Description = new GraphQLObjectType({
    name:'description',
    fields:()=>({
        standard:{type: GraphQLString},
        short:{type: GraphQLString},
    })
})

const PlaylistDetails = new GraphQLObjectType({
    name:'playlistDetails',
    fields:()=>({
        id:{type: GraphQLString},
        type:{type: GraphQLString},
        href:{type: GraphQLString},
        relationships:{type: Relationships},
        attributes:{type: Attributes},
    })
})

module.exports = PlaylistDetails

