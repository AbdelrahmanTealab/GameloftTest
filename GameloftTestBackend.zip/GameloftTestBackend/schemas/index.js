const graphql = require("graphql");
const {
    GraphQLObjectType,
    GraphQLSchema,
    GraphQLList,
    GraphQLString
    } = graphql;
const {graphqlHTTP} = require("express-graphql");
const PlaylistDetails = require("./typedefs/PlaylistDetails");
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

var APPLE_MUSIC_PLAYLIST_DETAILS = null
var TOKEN = '>>>> TOKEN HERE <<<<'
fetch('https://api.music.apple.com/v1/catalog/ca/playlists?ids=pl.1a7fd42205674dd282d106f533f4bea6,pl.94aeee85f6bd48058d1a53873db1e66d,pl.c684d47c46924bcdbc4a065dd370a8d5,pl.ae12fec18a8b471788ee5956ac67b95a,pl.b0fcf5b1d96540789f36c6a29dcaa289', { 
    method: 'GET', 
    headers: {'Authorization': 'Bearer '+TOKEN}
    }).then((res) => res.json())
    .then((result) => {
        APPLE_MUSIC_PLAYLIST_DETAILS = result.data
    });

const RootQuery = new GraphQLObjectType({
    name:'rootQuery',
    fields:{
        getPlaylistDetails:{
            type: new GraphQLList(PlaylistDetails),
            args: null,
            resolve(parent, args){ return APPLE_MUSIC_PLAYLIST_DETAILS}
        },
        getPlaylistDetailsByID:{
            type: new GraphQLList(PlaylistDetails),
            args: {id: {type: GraphQLString}},
            resolve(parent, args){ return APPLE_MUSIC_PLAYLIST_DETAILS.filter(pl=>{return pl.id == args.id})}
        }
    }
});
const Mutation = null;

module.exports = new GraphQLSchema({query: RootQuery, mutation: Mutation})